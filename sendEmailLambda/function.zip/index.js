const AWS = require("aws-sdk");
AWS.config.update({ 
    region: process.env.region, 
    endpoint: process.env.endpoint,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});
// const recSqsURL = "https://sqs.ap-southeast-2.amazonaws.com/245866473499/AW_RECEIVE_Q";
// const recSqsURL = "http://localhost:4566/000000000000/AW_RECEIVE_Q";

const sourceEmail = process.env.region;

exports.handler = async (event) => {
    
    // const { email, userName, verificationLink } = JSON.parse(event.Records[0].body);
    const { email, userName, verificationLink } = event.Records[0].body;
    console.log('To Address: ', email,', UserName is: ',userName,' ,Verification link is: ',verificationLink);
    const emailTemplate = getTemplateFromS3Bucket();
    const sesPromise = sendEmail(emailTemplate, email);
    sendMessageToSQS(email, sesPromise);
    return {
        statusCode: 200,
        body: {
            toAddress: email,
            userName: userName,
            verificationLink: verificationLink
        }
    }
};

async function getTemplateFromS3Bucket() {
    const bktParams = {
        Bucket: process.env.s3Bucket,
        Key: process.env.s3Key
    };
    const s3 = new AWS.S3({ apiVersion: '2006-03-01', sslEnabled: false, s3ForcePathStyle:true});
    const template = await s3.getObject(bktParams).promise();
    const htmlStr = template.Body.toString();
    return htmlStr;
}

function sendEmail(emailTemplate, destinationEmail) {
    const sesParams = {
        Destination: {
            ToAddresses: [destinationEmail],
        },
        Message: {
            Body: {
                Html: {
                    Charset: 'UTF-8',
                    Data: eval(`\`${emailTemplate}\``),
                },
                Text: {
                    Data: eval(`\`${emailTemplate}\``)
                }
            },
            Subject: {
                Charset: 'UTF-8',
                Data: 'Thanks for registering with AsyncWorking!',
            },
        },
        Source: sourceEmail,
    };
    const ses = new AWS.SES({ apiVersion: '2010-12-01', endpoint: process.env.sesLocalEndpoint });
    return sesPromise = ses.sendEmail(sesParams).promise();
}

function sendMessageToSQS(email, sesPromise) {
    const sqsParams = {
        MessageBody: email,
        QueueUrl: process.env.sqsQueueUrl
    };
    const sqs = new AWS.SQS({apiVersion: '2012-11-05'});
    const sqsPromise = sesPromise.then(()=>{
        return new Promise((resolve,reject)=>{
            sqs.sendMessage(sqsParams,(err, data)=>{
                if (err) {
                    console.log("SQS send error"+err);
                    reject(err);
                } else {
                    console.log("Success", data.MessageId);
                    resolve("Success: SQS message has been sent!");
                }
            });
        });
    },reason=>{
        throw reason;
    });
    return sqsPromise;
}